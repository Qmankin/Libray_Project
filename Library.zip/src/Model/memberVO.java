package Model;

public class memberVO {

}
