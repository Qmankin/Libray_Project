package Model;

public class bookVO {
	private int bno;
	private String brno;
	private String bname;
	private String byear;
	private String publisher;		
	private String writer;	
	private String bcode;
	
	public bookVO() {
	}



	public bookVO(String brno, String bname, String byear, String publisher, String writer, String bcode) {
		super();
		this.brno = brno;
		this.bname = bname;
		this.byear = byear;
		this.publisher = publisher;
		this.writer = writer;
		this.bcode = bcode;
	}



	public bookVO(int bno, String brno, String bname, String byear, String publisher, String writer, String bcode) {
		super();
		this.bno = bno;
		this.brno = brno;
		this.bname = bname;
		this.byear = byear;
		this.publisher = publisher;
		this.writer = writer;
		this.bcode = bcode;
	}




	public int getBno() {
		return bno;
	}



	public void setBno(int bno) {
		this.bno = bno;
	}



	public String getBrno() {
		return brno;
	}



	public void setBrno(String brno) {
		this.brno = brno;
	}



	public String getBname() {
		return bname;
	}



	public void setBname(String bname) {
		this.bname = bname;
	}



	public String getByear() {
		return byear;
	}



	public void setByear(String byear) {
		this.byear = byear;
	}



	public String getPublisher() {
		return publisher;
	}



	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}



	public String getWriter() {
		return writer;
	}



	public void setWriter(String writer) {
		this.writer = writer;
	}



	public String getBcode() {
		return bcode;
	}



	public void setBcode(String bcode) {
		this.bcode = bcode;
	}



	@Override
	public String toString() {
		return "bookVO [bno=" + bno + ", brno=" + brno + ", bname=" + bname + ", byear=" + byear + ", publisher="
				+ publisher + ", writer=" + writer + ", bcode=" + bcode + "]";
	}
	
	
	
	
}
