package Controller;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.sun.javafx.scene.traversal.TopMostTraversalEngine;

import Model.bookVO;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.css.ParsedValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class RootController implements Initializable {
	@FXML
	private TableView<bookVO> bTable = new TableView<>();
	@FXML
	private TextField txtBrno;
	@FXML
	private TextField txtBname;
	@FXML
	private DatePicker dpByear;
	@FXML
	private TextField txtPublisher;
	@FXML
	private TextField txtWriter;
	@FXML
	private TextField txtBcode;
	@FXML
	private Button btnBinsert;
	@FXML
	private Button btnBedit;
	@FXML
	private Button btnBdelete;
	@FXML
	private Button btnBexit;
	@FXML
	private ImageView bImageView;
	@FXML
	private Button btnBimageFile;
	@FXML
	private TextField txtBsearch;
	@FXML
	private Button btnBsearch;
	@FXML
	private Button btnBtotalList;
	@FXML
	private Button btnEdit;
	@FXML
	private Button btnFormAdd;
	@FXML
	private Button btnFormCancel;

	ObservableList<bookVO> data = FXCollections.observableArrayList();
	ObservableList<bookVO> selectBook = null; // ���̺����� ������ ���� ����
	// bookVO book = new bookVO();
	bookDAO bDao = null;
	bookVO bVo = null;

	boolean editDelete = false; // Ȯ�� ���� ��ư ����
	int selectedIndex; // ���̺����� ������ ���� ���� �ε��� ����

	private Stage primaryStage;

	int bno;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		// ���̺� �� �÷��̸� ����
		TableColumn colBno = new TableColumn("NO.");
		colBno.setMaxWidth(30);
		colBno.setCellValueFactory(new PropertyValueFactory<>("bno"));

		TableColumn colBrno = new TableColumn("��Ϲ�ȣ");
		colBrno.setMinWidth(100);
		colBrno.setCellValueFactory(new PropertyValueFactory<>("brno"));

		TableColumn colBname = new TableColumn("������");
		colBname.setMinWidth(300);
		colBname.setCellValueFactory(new PropertyValueFactory<>("bname"));

		TableColumn colByear = new TableColumn("���࿬��");
		colByear.setMinWidth(110);
		colByear.setCellValueFactory(new PropertyValueFactory<>("byear"));

		TableColumn colPublisher = new TableColumn("���ǻ�");
		colPublisher.setMaxWidth(100);
		colPublisher.setCellValueFactory(new PropertyValueFactory<>("publisher"));

		TableColumn colWriter = new TableColumn("�۰�");
		colWriter.setMaxWidth(100);
		colWriter.setCellValueFactory(new PropertyValueFactory<>("writer"));

		TableColumn colBcode = new TableColumn("û����ȣ");
		colBcode.setMinWidth(130);
		colBcode.setCellValueFactory(new PropertyValueFactory<>("bcode"));

		bTable.getColumns().addAll(colBno, colBrno, colBname, colByear, colPublisher, colWriter, colBcode);
		btnBinsert.setOnAction(event -> handlerBtnBinsertAction(event));

		// ���� ��ü ����
		bTotalList();
		bTable.setItems(data);

		// ��ü ����Ʈ
		btnBtotalList.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				try {
					data.removeAll(data);
					// ���� ��ü ����
					bTotalList();
				} catch (Exception e) {
					System.out.println("���� ��ü����Ʈ" + e);
				}
			}
		});

		btnBedit.setOnAction(event -> handlerBtnBeditAction(event));
		btnBexit.setOnAction(event -> handlerBtnBexitAction(event));
		btnBdelete.setOnAction(event -> handlerBtnBdeleteAction(event));
		btnBsearch.setOnAction(event -> handlerBtnBsearchAction(event));

	}

	public void handlerBtnBeditAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/formedit.fxml"));
			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btnBinsert.getScene().getWindow());
			dialog.setTitle("����");

			Parent parentEdit = (Parent) loader.load();
			bookVO bookEdit = bTable.getSelectionModel().getSelectedItem();
			selectedIndex = bTable.getSelectionModel().getSelectedIndex();

			TextField editBno = (TextField) parentEdit.lookup("#txtBno");
			TextField editBrno = (TextField) parentEdit.lookup("#txtBrno");
			TextField editBname = (TextField) parentEdit.lookup("#txtBname");
			TextField editByear = (TextField) parentEdit.lookup("#txtByear");
			TextField editPublisher = (TextField) parentEdit.lookup("#txtPublisher");
			TextField editWriter = (TextField) parentEdit.lookup("#txtWriter");
			TextField editBcode = (TextField) parentEdit.lookup("#txtBcode");

			editBno.setText(bookEdit.getBno()+ "");
			editBrno.setText(bookEdit.getBrno());
			editBname.setText(bookEdit.getBname());
			editByear.setText(bookEdit.getByear());
			editWriter.setText(bookEdit.getWriter());
			editPublisher.setText(bookEdit.getPublisher());
			editBcode.setText(bookEdit.getBcode());

			btnFormAdd.setOnAction(e -> {
				bookVO bVo = null;
				bookDAO bDao = null;

				TextField txtBno = (TextField) parentEdit.lookup("#txtBno");
				TextField txtBrno = (TextField) parentEdit.lookup("txtBrno");
				TextField txtBname = (TextField) parentEdit.lookup("#txtBname");
				TextField txtByear = (TextField) parentEdit.lookup("#txtByear");
				TextField txtPublisher = (TextField) parentEdit.lookup("#txtPublisher");
				TextField txtWriter = (TextField) parentEdit.lookup("#txtWriter");
				TextField txtBcode = (TextField) parentEdit.lookup("#txtBcode");

				data.remove(selectedIndex);
				try {
					bVo = new bookVO(Integer.parseInt(txtBno.getText()), txtBrno.getText(), txtBname.getText(),
							txtByear.getText(), txtPublisher.getText(), txtWriter.getText(), txtBcode.getText());
					dialog.close();

					bDao = new bookDAO();
					bDao.getBookUpdate(bVo, bVo.getBno());

					data.removeAll(data);
					bTotalList();

				} catch (Exception e1) {
					e1.printStackTrace();
				}
			});

			btnFormCancel.setOnAction(e -> {
				dialog.close();
			});

			Scene scene = new Scene(parentEdit);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();
		} catch (IOException e) {
			System.out.println(e.toString());
		}
	}

	public void handlerBtnBsearchAction(ActionEvent event) {
		bookVO bVo = new bookVO();
		bookDAO bDao = null;
		
		Object[][] totalData = null;
		
		String searchName = "";
		boolean	searchResult = false;
		
		try {
			searchName = txtBsearch.getText();
			bDao = new bookDAO();
			bVo = bDao.getBookCheck(searchName);
			
			if(searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�л� ���� �˻�");
				alert.setHeaderText("�л��� �̸��� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
			if(!searchName.equals("")&&(bVo != null)) {
				ArrayList<String> title;
				ArrayList<bookVO> list;
				
				title = bDao.getColumnName();
				int columnCount = title.size();
				
				list = bDao.getBookTotal();
				int rowCount = list.size();
				
				totalData = new Object[rowCount][columnCount];
				
				if (bVo.getBname().equals(searchName)) {
					
					txtBsearch.clear();
					data.removeAll(data);
					for (int index =0; index < rowCount; index++) {
						bVo = list.get(index);
						if(bVo.getBname().equals(searchName)) {
							data.add(bVo);
							searchResult = true;
						}
					}
				}
			}
			
			if (!searchResult) {
				txtBsearch.clear();
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л� ���� �˻�");
				alert.setHeaderText(searchName + "�л��� ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���.");
				alert.showAndWait();
			}
		}catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("�л� ���� �˻� ����");
			alert.setHeaderText("�л� ���� �˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���");
		}
	}

	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	public void handlerBtnBdeleteAction(ActionEvent event) {
		bookDAO bDao = null;
		bDao = new bookDAO();

		try {
			bDao.getBookDelete(bno);
			data.removeAll(data);
			// ���� ��ü ����
			bTotalList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		editDelete = true;
	}

	public void handlerBtnBexitAction(ActionEvent event) {
		Platform.exit();
	}

	public void bTotalList() {
		Object[][] totalData;

		bDao = new bookDAO();
		bVo = new bookVO();
		ArrayList<String> title;
		ArrayList<bookVO> list;

		title = bDao.getColumnName();
		int columnCount = title.size();

		list = bDao.getBookTotal();
		int rowCount = list.size();
		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			bVo = list.get(index);
			System.out.println(bVo);
			data.add(bVo);
		}
	}

	// ���� ���
	public void handlerBtnBinsertAction(ActionEvent event) {
		try {
			data.removeAll(data);
			bookVO bvo = null;
			bookDAO bdao = null;

			bvo = new bookVO(txtBrno.getText(), txtBname.getText(), dpByear.getValue().toString(),
					txtPublisher.getText(), txtWriter.getText(), txtBcode.getText());

			bdao = new bookDAO();
			bdao.getBookregiste(bvo);
			bTotalList();

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� ���� �Է�");
			alert.setHeaderText("���� ������ ��Ȯ�� �Է��Ͻÿ�.");
			alert.setContentText("�������� ��Ȯ�� �Է��ϼ���!");
			alert.showAndWait();
		}
	}
	// ��ư �ϳ����� �����ϱ� ������
}
