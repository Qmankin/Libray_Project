package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;

public class LoginController implements Initializable {

	@FXML
	private TextField txtId;
	@FXML
	private PasswordField txtPassword;
	@FXML
	private Button btnCancel;
	@FXML
	private Button btnLogin;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		btnLogin.setOnAction(event -> handlerBtnLoginAction(event));
		btnCancel.setOnAction(event -> handlerBtnCancelAction(event));
	}

	public void handlerBtnCancelAction(ActionEvent event) {
		Platform.exit();
	}

	public void handlerBtnLoginAction(ActionEvent event) {
		
		Alert alert;
		if(txtId.getText().equals("")||txtPassword.getText().equals("")) {
			alert = new Alert(AlertType.WARNING);
			alert.setTitle("�α��� ����");
			alert.setHeaderText("���̵�� ��й�ȣ ���Է�");
			alert.setContentText("���̵�� ��й�ȣ�� �Է����� ���� �׸��� �ֽ��ϴ�." + "\n �ٽ� ����� �Է��Ͻÿ�.");
			alert.setResizable(false);
			alert.showAndWait();
			return;
		}
		
		if(txtId.getText().equals("Qmankin")&&txtPassword.getText().equals("8579263a")) {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/library.fxml"));
				Parent mainView = (Parent)loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("Main Window");
				mainMtage.setScene(scene);
				Stage oldStage = (Stage)btnLogin.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			}catch (IOException e) {
				System.err.println("����" + e);
			}
		}else {
			alert = new Alert(AlertType.WARNING);
			alert.setTitle("�α��� ����");
			alert.setHeaderText("���̵�� ��й�ȣ ����ġ");
			alert.setContentText("���̵�� ��й�ȣ�� ��ġ���� �ʽ��ϴ�." + "\n �ٽ� ����� �Է��Ͻÿ�.");
			alert.showAndWait();
		}
	}
}
